create database insurancesystem;
use insurancesystem;
create table users (userId INT auto_increment primary key, username varchar(50), password varchar(30));
table might need to be readjusted later on as we add functional components to the web application.

ENSURE YOU ENTER YOUR mysql password ON backend>server.js


To run this file, first run -<npm install> on backend and on root
then run -<npm start> on backend, cd .. to root, run -<npm start> on root

