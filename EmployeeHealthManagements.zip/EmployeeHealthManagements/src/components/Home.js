import React from "react";
import { Link } from "react-router-dom";
import "../styles/home.css"
function Home() {
  return (
    <div>
      <h1 className="txt-options">There's always an option for you...</h1>
      <div className="btns">
        <Link to="/viewinsurances">
          <button className="btn btn-insurance">Policy Portal</button>
        </Link>
        
        <Link to="/viewemployees">
          <button className="btn btn-employee">Employee Portal</button>
        </Link>

        <Link to="/login">
          <button className="btn btn-back"> Go Back </button>
        </Link>

      </div>
    </div>
  );
}

export default Home;
